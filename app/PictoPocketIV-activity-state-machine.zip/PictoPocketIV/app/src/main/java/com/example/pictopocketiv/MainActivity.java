package com.example.pictopocketiv;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pictopocketiv.arasaac.ArasaacModel;
import com.example.pictopocketiv.arasaac.ArasaacService;
import com.example.pictopocketiv.firebase.FirebaseAuthService;
import com.example.pictopocketiv.states.MainActivityStatusModelView;
import com.example.pictopocketiv.firebase.FirebaseService;
import com.example.pictopocketiv.localpersistence.PictoImagesPersistenceService;
import com.example.pictopocketiv.localpersistence.PictosLocalPersistenceService;
import com.example.pictopocketiv.localpersistence.PictosPersistenceModel;
import com.example.pictopocketiv.localpersistence.PictvsPopulator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();


    // ---- Activity state ---- //
    private MainActivityStatusModelView mActivityMV;

    // ---- App permissions ---- //
    private static final String[] permissions = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE};

    private static final int REQUEST_PERMISSION_CODE = 100;
    private TextView mStateTxt;
    private Button mOkBtn;
    private Button mKoBtn;
    private Button mKo2Btn;
    private Button mLoginOkBtn;
    private Button mLoginKoBtn;
    private Button mLogoutOkBtn;
    private EditText mUserOkTxt;
    private EditText mPassOkTxt;
    private Button mSignupOkBtn;


    // ==== LIFECYCLE === //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configApp();
        confAuth();
        confActivity();
        confUI();

    }


    // ==== App ==== //
    private void configApp() {
        setAppPermissions();
    }


    // ==== ACTIVITY ==== //
    private void confActivity() {
        setLocalPersistence();
        setArasaacService();
        setFirebase();
        confActivityState();
    }

    private void confActivityState() {

        mActivityMV = new ViewModelProvider(this).get(MainActivityStatusModelView.class);
        mActivityMV.setStatus(MainActivityStatusModelView.ActivityStatus.CH_AUTH_STATE);

        // Add an a auth modelView observer (to listen status changes
        // in another components)
        mActivityMV.getStatus().observe(this, activityStatus -> {
            updateActivityState(activityStatus);
        });
    }

    private void updateActivityState(MainActivityStatusModelView.ActivityStatus activityStatus) {

        Log.d(TAG,String.format("NEW state %s",mActivityMV.getStatus().getValue()));

        mStateTxt.setText(mActivityMV.getStatus().getValue().toString());

        switch (activityStatus) {
            case LOGGED_IN:
                goLoggedIn();
                break;
            case W_USER_CREDENTIALS:
                goLogin();
                break;
            case W_SIGNUP_CREDENTIALS:
                goSignup();
                break;
            case W_DB_POPULATION:
                goDBPopulation();
                break;
            case CH_AUTH_STATE:
                goCheckAuthState();
                break;
            case W_SIGNUP_RSP:
            case W_USER_CREDENTIALS_RSP:
                goWait(activityStatus);
                break;
            case E_INVALID_CREDENTIALS:
            case E_INVALID_SIGNUP:
            case E_INVALID_USER:
            case E_UNDEFINED:
                goError(activityStatus);
            default:
                break;
        }
    }

    // States handlers //
    private void goCheckAuthState() {
        mActivityMV.setStatus(MainActivityStatusModelView.Signal.KO);
    }

    private void goDBPopulation() {

        // TODO: Check first if the DB is already populated
        try {
            testPopvlator();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        mActivityMV.setStatus(MainActivityStatusModelView.Signal.OK);
    }

    private void goError(MainActivityStatusModelView.ActivityStatus activityStatus) {

    }

    private void goWait(MainActivityStatusModelView.ActivityStatus activityStatus) {
    }

    private void goSignup() {

    }

    private void goLogin() {
    }

    private void goLoggedIn() {

    }


    // ==== ARASAAC ==== //
    private void setArasaacService() {
        ArasaacService.initService("https://api.arasaac.org/");     // arasaac service
    }


    // ==== FIREBASE ==== //
    private void setFirebase() {
        FirebaseService.init(this);
    }


    // ==== AUTH (firebase) ==== //
    private void confAuth() {
        // Add an Firebase auth state change listener
        FirebaseAuth.getInstance().addAuthStateListener(onAuthStateChange);
    }

    private FirebaseAuth.AuthStateListener onAuthStateChange = new FirebaseAuth.AuthStateListener() {
        @Override
        public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

            Log.d(TAG, "Auth State changed");

            if(firebaseAuth.getCurrentUser() != null) {
                mActivityMV.setStatus(MainActivityStatusModelView.ActivityStatus.W_DB_POPULATION);
                Log.d(TAG, "Logged");
            } else {
                mActivityMV.setStatus(MainActivityStatusModelView.ActivityStatus.W_USER_CREDENTIALS);
                Log.d(TAG, "Unlogged");
            }
        }
    };


    // ==== LOCAL PERSISTENCE ==== //
    private void setLocalPersistence() {
        PictosLocalPersistenceService.init(this,"db_pictos_db");    // local persistence
    }


    // ==== PERMISSIONS ==== //
    private void setAppPermissions() {
        checkPermissions(); // app permissions
    }

    private boolean checkPermissions() {

        boolean granted = true;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {   // Request permissions required in Android 23<=

            for(String permission:permissions) {
                if(checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED ) {
                    granted = false;
                }
            }

            if(!granted) {   // if all permissions granted

                requestPermissions(permissions,REQUEST_PERMISSION_CODE);
            }
        }

        return granted;
    }

    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if( requestCode == REQUEST_PERMISSION_CODE) {

            boolean allGranted = true;

            for( int result: grantResults) {
                if(result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                }
            }

            if(!allGranted)
                Toast.makeText(this,"Permiso denegado", Toast.LENGTH_LONG).show();
            else
                Toast.makeText(this,"Permiso concedido", Toast.LENGTH_LONG).show();

        }
    }


    // ==== UI ==== //
    private void confUI() {
        confFakeWidgets();
        confFakeWidgetsListeners();
    }


    // ==== TEST ==== //
    private void confFakeWidgets() {
        mStateTxt = (TextView) findViewById(R.id.current_activity_state);
        mOkBtn = (Button) findViewById(R.id.ok_btn);
        mKoBtn = (Button) findViewById(R.id.ko_btn);
        mKo2Btn = (Button) findViewById(R.id.ko2_btn);

        mLoginOkBtn = (Button) findViewById(R.id.login_ok_btn);
        mLoginKoBtn = (Button) findViewById(R.id.login_ko_btn);
        mLogoutOkBtn = (Button) findViewById(R.id.logout_ok_btn);

        mUserOkTxt = (EditText) findViewById(R.id.user_name_ok_txt);
        mPassOkTxt = (EditText) findViewById(R.id.password_ok_txt);
        mSignupOkBtn = (Button) findViewById(R.id.signup_ok_btn);
    }

    private void confFakeWidgetsListeners() {
        mOkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivityMV.setStatus(MainActivityStatusModelView.Signal.OK);
            }
        });
        mKoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivityMV.setStatus(MainActivityStatusModelView.Signal.KO);
            }
        });
        mKo2Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivityMV.setStatus(MainActivityStatusModelView.Signal.KO2);
            }
        });

        // Session
        FirebaseAuthService.OnOpenSession onOpenSession = new FirebaseAuthService.OnOpenSession() {
            @Override
            public void onSuccess() {
                mActivityMV.setStatus(MainActivityStatusModelView.Signal.OK);
            }

            @Override
            public void onFailure(Exception e) {
                if(e instanceof FirebaseAuthInvalidUserException) {
                    mActivityMV.setStatus(MainActivityStatusModelView.Signal.KO2);
                } else if (e instanceof FirebaseAuthInvalidCredentialsException){
                    mActivityMV.setStatus(MainActivityStatusModelView.Signal.KO);
                } else {
                    mActivityMV.setStatus(MainActivityStatusModelView.Signal.KO);
                }
                Log.e(TAG,e.getMessage());
            }
        };

        mLoginOkBtn.setOnClickListener(view -> {

            mActivityMV.setStatus(MainActivityStatusModelView.ActivityStatus.W_USER_CREDENTIALS_RSP);

            String email = "qqq@qqqq.com";
            String pass = "123456AAA";


            FirebaseAuthService.openSession(email,pass,onOpenSession);
        });
        mLoginKoBtn.setOnClickListener(view -> {

            mActivityMV.setStatus(MainActivityStatusModelView.ActivityStatus.W_USER_CREDENTIALS_RSP);


            String email = "qqxq@qqqq.com";
            String pass = "123456AAA";

            FirebaseAuthService.openSession(email,pass,onOpenSession);
        });
        mLogoutOkBtn.setOnClickListener(view -> {
            mActivityMV.setStatus(MainActivityStatusModelView.ActivityStatus.LOGGED_IN);
            FirebaseAuthService.logout();
        });

        // Signup
        FirebaseAuthService.OnUserCreation onUserCreation = new FirebaseAuthService.OnUserCreation() {
            @Override
            public void onCreationSuccess() {
                mActivityMV.setStatus(MainActivityStatusModelView.Signal.OK);
            }

            @Override
            public void onCreationFailure(Exception e) {
                Log.d(TAG,e.getMessage());
                e.printStackTrace();
                mActivityMV.setStatus(MainActivityStatusModelView.Signal.KO);
            }
        };

        mSignupOkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivityMV.setStatus(MainActivityStatusModelView.ActivityStatus.W_SIGNUP_RSP);

                String email = mUserOkTxt.getText().toString();
                String pass = mPassOkTxt.getText().toString();


                FirebaseAuthService.createaAccount(email,pass,onUserCreation);
            }
        });
    }

    private void testPopvlator() throws IOException, ExecutionException, InterruptedException {
        PictvsPopulator.welcomePopulate(
                this,
                "es",
                null,
                500,
                null,
                null,
                getPackageName()
        );
    }

    private void testArasaacApi() throws Exception {
        Log.d(TAG,"sync test started");
        //ArasaacModel.Pictogram pictogram = ArasaacService.getPictogram(35547, "es");
        //Bitmap pictogramBmp = ArasaacService.getPictogramImage(35547, 500);
        Log.d(TAG,"test finished");

        Log.d(TAG,"test sync started");
        ArasaacService.GetPictogramAsync getPictogramAsync =
                new ArasaacService.GetPictogramAsync("es", null);

        ArasaacModel.Pictogram pictogram = getPictogramAsync.execute(35547).get();


        ArasaacService.GetPictogramImageAsync getPictogramImageAsync =
                new ArasaacService.GetPictogramImageAsync(null, 500);

        Bitmap pictoImg = getPictogramImageAsync.execute(35547).get();

        PictosLocalPersistenceService.AddPictoAsync addPictoAsync =
                new PictosLocalPersistenceService.AddPictoAsync(null,0);

        PictosPersistenceModel.Picto picto = addPictoAsync.execute(pictogram).get();

        PictoImagesPersistenceService.StorePictoImage storePictoImageAsync =
                new PictoImagesPersistenceService.StorePictoImage(
                        null,pictoImg,picto.id, getPackageName());

        String imgUrl = storePictoImageAsync.execute().get();



        Log.d(TAG,"test finished");

    }
}