package com.example.pictopocketiv.firebase;

import com.example.pictopocketiv.states.MainActivityStatusModelView;

public class FirebaseAuthService {

    public enum AuthState {
        LOGGED_IN,
        LOGGED_OUT
    }

    // ===== Response interfaces ==== //
    public interface OnOpenSession {
        void onSuccess();
        void onFailure(Exception e);
    }

    public interface OnUserCreation {
        void onCreationSuccess();
        void onCreationFailure(Exception e);
    }

    // ==== Access Status ==== //
    public static AuthState getCurrentStatus() {
        if(FirebaseService.fbAuth.getCurrentUser() != null) {
            return AuthState.LOGGED_IN;
        } else {
            return AuthState.LOGGED_OUT;
        }
    }

    // ==== Session ops ==== //
    public static void openSession(String userMail, String userPass,
                                   OnOpenSession onOpenSession ) {

        FirebaseService.fbAuth.signInWithEmailAndPassword(userMail,userPass).addOnCompleteListener(task -> {
            if(task.isSuccessful()) {
                if(onOpenSession != null)
                    onOpenSession.onSuccess();
            } else {
                if(onOpenSession != null)
                    onOpenSession.onFailure(task.getException());
            }
        });
    }

    public static void createaAccount(String userMail, String userPass,
                                      OnUserCreation onUserCreation ) {
        FirebaseService.fbAuth.createUserWithEmailAndPassword(userMail,userPass)
                .addOnCompleteListener(task -> {
            if(task.isSuccessful()) {
                if(onUserCreation != null)
                    onUserCreation.onCreationSuccess();
            } else {
                if(onUserCreation != null)
                    onUserCreation.onCreationFailure(task.getException());
            }
        });
    }

    public static void logout() {
        FirebaseService.fbAuth.signOut();
    }
}
