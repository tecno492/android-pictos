package com.example.pictopocketiv.localpersistence;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class PictoImagesPersistenceService {


    // ==== STORAGE ==== //
    public static String storePictoImage(int id, Bitmap bmp, String appName ) throws IOException {

        String fileName = getPictoFileName(id + "");
        String path = getPictoImagesPath(appName);
        return storeImage(fileName,path,bmp);
    }

    public static String storeImage(String fileName, String path, Bitmap bmp ) throws IOException {

        File picsDir = new File(path);

        if(!picsDir.exists())  // create dir if doesn't exists
            picsDir.mkdirs();

        File imgFile = new File(picsDir, fileName);

        if(imgFile.exists()) {
            imgFile.createNewFile();
            imgFile = new File(picsDir,fileName);
        }

        FileOutputStream fout = new FileOutputStream(imgFile);
        bmp.compress(Bitmap.CompressFormat.PNG, 100, fout);
        fout.close();

        return imgFile.getAbsolutePath();

    }


    // ==== ASYNC STORAGE ==== //
    public static  class StorePictoImage extends AsyncTask<Void, Void, String> {

        public interface OnStored {
            void onSuccess(String url);
            void onFailure(Throwable t);
        }

        private OnStored mOnStored;
        private Bitmap mBmp;
        private int mId;
        private String mAppName;


        public StorePictoImage(OnStored onStored, Bitmap bm, int id, String mAppName) {
            this.mOnStored = onStored;
            this.mBmp = bm;
            this.mId = id;
            this.mAppName = mAppName;
        }

        @Override
        protected String doInBackground(Void... voids) {

            try {
                String imgUrl = storePictoImage(mId, mBmp, mAppName);
                return imgUrl;
            } catch (IOException e) {
                e.printStackTrace();
                if(mOnStored != null)
                    mOnStored.onFailure(e);
            }

            return null;
        }

        @Override
        protected void onPostExecute(String imgUrl) {
            super.onPostExecute(imgUrl);
            if(mOnStored != null)
                mOnStored.onSuccess(imgUrl);
        }
    }

    // ==== Paths ==== //
    public static String getPictoFileName(String pictoId) {
        return String.format("%s.png",pictoId);
    }

    public static String getPictoImagesPath(String appName ) {
        return Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES)
                + String.format("/%s/",appName);

    }


}
