package com.example.pictopocketiv.localpersistence;

import static com.example.pictopocketiv.localpersistence.PictosPersistenceModel.*;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.room.Room;

import com.example.pictopocketiv.arasaac.ArasaacModel;

import java.util.List;

public class PictosLocalPersistenceService {

    private static final String TAG = PictosLocalPersistenceService.class.getSimpleName();
    private static PictosDB pictosDB;
    private static Dao pictosDAO;

    public static void init(Context context, String dbName) {
        pictosDB = Room.databaseBuilder(context,
                PictosDB.class,
                dbName).build();

        pictosDAO = pictosDB.dao();
    }


    // === Insert Ops
    private static Picto addArasaacPictogram(ArasaacModel.Pictogram pictogram, int category ) {

        Picto picto = null;

        if (pictogram != null) {
            picto =
                    ArasaacAdapter.adapt(pictogram, category);
            List<Keyword> keywords =
                    ArasaacAdapter.adaptKeywords(pictogram);

            List<PictoKeyword> pictosKws =
                    ArasaacAdapter.adaptPictosKws(picto,keywords);

            addPicto(picto);
            addKeywords(keywords);
            addpictosKws(pictosKws);
        }

        return picto;

    }

    private static void addpictosKws(List<PictoKeyword> pictosKws) {
        for (PictoKeyword pictoKw : pictosKws) {
            try {
                pictosDAO.addPictoKeyword(pictoKw);
            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }
        }
    }

    private static void addKeywords(List<Keyword> keywords) {
        for (Keyword keyword : keywords) {
            try {
                pictosDAO.addKeyword(keyword);
            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }
        }
    }

    private static void addPicto(Picto picto) {
        try {
            pictosDAO.addPicto(picto);
        } catch (Exception e) {
            Log.e(TAG,e.getMessage());
        }
    }


    // ==== Async ops ==== //
    public static class AddPictoAsync extends AsyncTask<ArasaacModel.Pictogram, Void, Picto> {

        public interface OnAddPicto {
            void onSuccess(Picto picto);
            void onFailure(Throwable t);
        }

        private OnAddPicto mOnAddPicto;


        private int mCategory;

        public AddPictoAsync(OnAddPicto onAddPicto, int category) {
            this.mOnAddPicto = onAddPicto;
            this.mCategory = category;
        }

        @Override
        protected Picto doInBackground(ArasaacModel.Pictogram... pictograms) {

            Picto picto = addArasaacPictogram(pictograms[0],mCategory);

            return picto;
        }

        @Override
        protected void onPostExecute(Picto picto) {
            super.onPostExecute(picto);
            if(mOnAddPicto != null )
                mOnAddPicto.onSuccess(picto);
        }
    }

}

