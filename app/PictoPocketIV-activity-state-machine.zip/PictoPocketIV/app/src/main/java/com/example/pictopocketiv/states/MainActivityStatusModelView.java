package com.example.pictopocketiv.states;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MainActivityStatusModelView extends ViewModel {

    public static enum Signal {
        OK,
        KO,
        KO2
    }

    public static enum ActivityStatus {

        CH_AUTH_STATE,  // checking auth state

        W_DB_POPULATION,    // Waiting for db population
        LOGGED_IN,

        W_USER_CREDENTIALS, // Waiting for user credentials
        W_USER_CREDENTIALS_RSP, // Waiting for loging response
        E_INVALID_CREDENTIALS,  // Error in credentials
        E_INVALID_USER, // Error in user data

        W_SIGNUP_CREDENTIALS,   // Waiting for signup credentials
        W_SIGNUP_RSP,  // Waiting for signup response
        E_INVALID_SIGNUP,   // Error in signup

        E_UNDEFINED  // Undefined error
    }


    private ActivityStatus nextState( Signal signal ) {

        switch (this.status.getValue()) {

            // On checking auth state
            case CH_AUTH_STATE:
                if(signal == Signal.OK)
                    return ActivityStatus.W_DB_POPULATION;
                else
                    return ActivityStatus.W_USER_CREDENTIALS;
            // On loggin
            case W_USER_CREDENTIALS:
                if(signal == Signal.OK)
                    return ActivityStatus.W_USER_CREDENTIALS_RSP;
                else
                    return ActivityStatus.W_SIGNUP_CREDENTIALS;

            case W_USER_CREDENTIALS_RSP:
                if(signal == Signal.OK)
                    return ActivityStatus.W_DB_POPULATION;
                else if(signal == Signal.KO )
                    return ActivityStatus.E_INVALID_CREDENTIALS;
                else
                    return ActivityStatus.E_INVALID_USER;

            case LOGGED_IN:
                if(signal == Signal.OK)
                    return ActivityStatus.LOGGED_IN;
                else
                    return ActivityStatus.W_USER_CREDENTIALS;

            case W_DB_POPULATION:
                if(signal == Signal.OK)
                    return ActivityStatus.LOGGED_IN;
                else
                    return ActivityStatus.W_DB_POPULATION;

            // On signup
            case W_SIGNUP_CREDENTIALS:
                if(signal == Signal.OK)
                    return ActivityStatus.W_SIGNUP_RSP;
                else
                    return ActivityStatus.W_USER_CREDENTIALS;
            case W_SIGNUP_RSP:
                if(signal == Signal.OK)
                    return ActivityStatus.W_DB_POPULATION;
                else
                    return ActivityStatus.E_INVALID_SIGNUP;

            // On Error
            case E_UNDEFINED:
                return ActivityStatus.E_UNDEFINED;
            case E_INVALID_CREDENTIALS:
                if(signal == Signal.OK)
                    return ActivityStatus.W_USER_CREDENTIALS;
                else
                    return ActivityStatus.E_INVALID_CREDENTIALS;
            case E_INVALID_USER:
                if(signal == Signal.OK)
                    return ActivityStatus.W_USER_CREDENTIALS;
                else
                    return ActivityStatus.E_INVALID_USER;
            case E_INVALID_SIGNUP:
                if(signal == Signal.OK)
                    return ActivityStatus.W_SIGNUP_CREDENTIALS;
                else
                    return ActivityStatus.E_INVALID_SIGNUP;
        }

        return ActivityStatus.E_UNDEFINED;
    }

    private MutableLiveData<ActivityStatus> status = new MutableLiveData<>();

    public void setStatus(ActivityStatus status) {
        this.status.setValue(status);
    }

    public void setStatus(Signal signal) {
        this.status.setValue(nextState(signal));
    }


    public LiveData<ActivityStatus> getStatus() {
        return this.status;
    }




}
