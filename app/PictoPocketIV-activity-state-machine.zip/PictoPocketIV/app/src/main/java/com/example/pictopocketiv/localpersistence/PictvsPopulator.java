package com.example.pictopocketiv.localpersistence;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;

import com.example.pictopocketiv.arasaac.ArasaacModel;
import com.example.pictopocketiv.arasaac.ArasaacService;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class PictvsPopulator {

    private static class CategorizedPictos {
        public int cat;
        public int[] ids;

        public CategorizedPictos(int cat, int[] ids) {
            this.cat = cat;
            this.ids = ids;
        }

        @Override
        public String toString() {
            return "CategorizedPictos{" +
                    "cat=" + cat +
                    ", ids=" + Arrays.toString(ids) +
                    '}';
        }
    }

    private static class CategorizedPictosList {
        public List<CategorizedPictos> pictoCats;

        @Override
        public String toString() {
            return "CategorizedPictosList{" +
                    "pictoCats=" + pictoCats +
                    '}';
        }
    }

    public static void welcomePopulate(
            Context context, String locale,
            ArasaacService.GetPictogramAsync.OnArasaacResponse onArasaacResponse,
            int resolution,
            ArasaacService.GetPictogramImageAsync.OnImageDownloaded onImageDownloaded,
            PictosLocalPersistenceService.AddPictoAsync.OnAddPicto onAddPicto,
            String packageName) throws IOException, ExecutionException, InterruptedException {

        CategorizedPictosList catList = readWelcomePictos(context);

        for (CategorizedPictos pictoCat : catList.pictoCats) {
            int cat = pictoCat.cat;

            for (int pictoId : pictoCat.ids) {
                // --- Get pictogram --- //
                ArasaacService.GetPictogramAsync getPictogramAsync =
                        new ArasaacService.GetPictogramAsync(locale, onArasaacResponse);
                ArasaacModel.Pictogram pictogram = getPictogramAsync.execute(pictoId).get();

                // --- Get pictogram Image --- //
                ArasaacService.GetPictogramImageAsync getPictogramImageAsync =
                        new ArasaacService.GetPictogramImageAsync(onImageDownloaded, resolution);

                Bitmap pictoImg = getPictogramImageAsync.execute(pictoId).get();

                // ---- Persists pictogram --- //
                PictosLocalPersistenceService.AddPictoAsync addPictoAsync =
                        new PictosLocalPersistenceService.AddPictoAsync(onAddPicto,pictoCat.cat);

                PictosPersistenceModel.Picto picto = addPictoAsync.execute(pictogram).get();

                // ---- Store pictogram image --- //
                PictoImagesPersistenceService.StorePictoImage storePictoImageAsync =
                        new PictoImagesPersistenceService.StorePictoImage(
                                null,pictoImg,picto.id, packageName);

                String imgUrl = storePictoImageAsync.execute().get();
            }
        }
    }

    public static PictvsPopulator.CategorizedPictosList readWelcomePictos(Context context)
            throws IOException {

        AssetManager assman = context.getAssets();
        InputStream istream = null;

        istream = assman.open("welcome_pictos_bundle.json");

        BufferedReader buffReader = new BufferedReader(
                new InputStreamReader(istream));
        StringBuilder strBuilder = new StringBuilder();
        String line;
        while ((line = buffReader.readLine()) != null ) {
            strBuilder.append(line);
        }

        String jsonStr = strBuilder.toString();

        Gson gson = new Gson();
        CategorizedPictosList pictos = gson.fromJson(jsonStr,CategorizedPictosList.class);

        return pictos;
    }

}
