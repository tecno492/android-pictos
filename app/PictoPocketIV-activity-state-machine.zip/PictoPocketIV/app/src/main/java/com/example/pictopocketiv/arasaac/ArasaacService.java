package com.example.pictopocketiv.arasaac;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.pictopocketiv.images.ImageUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

public class ArasaacService {

    private static final String TAG = ArasaacService.class.getSimpleName();
    private static ArasaacApiService apiService;

    // ==== Service Ops ==== //
    public static void initService(String apiUrl) {
        apiService = ArasaacApiClient.getClient(apiUrl).create(ArasaacApiService.class);
    }


    // ==== Entities Sync Ops ==== //
    public static ArasaacModel.Pictogram getPictogram(int pictoID, String locale) throws Exception {

        Call<ArasaacModel.Pictogram> pictogramCall = apiService.getPicto(locale,pictoID);

        Response<ArasaacModel.Pictogram> pictogramResponse = pictogramCall.execute(); // sync

        if(pictogramResponse.isSuccessful()) {
            return pictogramResponse.body();
        } else {
            throw new Exception(
                    String.format("Get pictogram error: response code: %s",
                            pictogramResponse.code()));
        }
    }

    public static List<ArasaacModel.Pictogram> getPictograms(int[] pictoIDs, String locale) {

        List<ArasaacModel.Pictogram> pictograms = new ArrayList<>();

        for (int pictoID : pictoIDs) {
            try {
                pictograms.add(getPictogram(pictoID,locale));

            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG,e.getMessage());
            }
        }

        return pictograms;
    }

    public static List<ArasaacModel.Pictogram> getPictogramsBySearchTerm(
            String SearchTerm, String locale) throws Exception {

        Call<List<ArasaacModel.Pictogram>> listCall = apiService.search(SearchTerm,locale);

        Response<List<ArasaacModel.Pictogram>> pictogramsResponse = listCall.execute();

        if(pictogramsResponse.isSuccessful()) {
            return pictogramsResponse.body();
        } else {
            throw new Exception(
                    String.format("Get pictogram error: response code: %s",
                            pictogramsResponse.code()));
        }
    }

    // === Images Ops === //
    public static Bitmap getPictogramImage(int pictoID, int resolution ) throws IOException {
        String imgUrl = getPictogramImageURL(pictoID, resolution);
        return ImageUtils.downloadImageSync(imgUrl);
    }

    public static List<Bitmap> getPictogramsImages(int[] pictoIDs, int resolution ) throws IOException {

        List<Bitmap> bmps = new ArrayList<>();

        for (int pictoID : pictoIDs) {
            bmps.add(getPictogramImage(pictoID,resolution));
        }

        return bmps;

    }

    public static String getPictogramImageURL(int pictoID, int resolution) {
        return String.format("https://static.arasaac.org/pictograms/%s/%s_%s.png",
                pictoID, pictoID, resolution);
    }


    // ==== Entities Async Ops ==== //
    public static class GetPictogramAsync extends AsyncTask<Integer,Void, ArasaacModel.Pictogram> {

        // --- Interface for asyncronous responses --- //
        public interface OnArasaacResponse {
            void onSuccess(ArasaacModel.Pictogram pictogram);
            void onFailure(Throwable t);
        }

        private String mLocale; // locale for query
        private OnArasaacResponse mOnArasaacResponse;

        // --- C --- //
        public GetPictogramAsync(@NonNull String locale,
                                 GetPictogramAsync.OnArasaacResponse onArasaacResponse) {
            this.mLocale = locale;
            this.mOnArasaacResponse = onArasaacResponse;
        }

        // --- Do in backgroound --- //
        @Override
        protected ArasaacModel.Pictogram doInBackground(@NonNull Integer... ids) {

            int pictoId = ids[0];

            ArasaacModel.Pictogram pictogram = null;
            try {
                pictogram = getPictogram(pictoId, mLocale);
            } catch (Exception e) {
                e.printStackTrace();
                if(mOnArasaacResponse != null)
                    mOnArasaacResponse.onFailure(e);
            }

            return pictogram;
        }

        // --- On post execute --- //
        @Override
        protected void onPostExecute(ArasaacModel.Pictogram pictogram) {
            super.onPostExecute(pictogram);
            if(mOnArasaacResponse != null )
                mOnArasaacResponse.onSuccess(pictogram);
        }
    }

    public static class GetPictogramImageAsync extends AsyncTask<Integer, Void, Bitmap> {


        // --- Response interface --- //
        public interface OnImageDownloaded {
            void onSuccess(Bitmap bm);
            void onFailure(Throwable t);
        }

        private OnImageDownloaded mOnImageDownloaded;   // for async
        private int mResolution;

        // ---- C ---- //
        public GetPictogramImageAsync(OnImageDownloaded onImageDownloaded, @NonNull int resolution) {
            this.mOnImageDownloaded = onImageDownloaded;
            this.mResolution = resolution;
        }

        // ---- Do in background --- //
        @Override
        protected Bitmap doInBackground(@NonNull Integer... ids) {

            int pictoId = ids[0];

            try {
                Bitmap bm = getPictogramImage(pictoId,mResolution);
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                if(mOnImageDownloaded != null )
                    mOnImageDownloaded.onFailure(e);
            }
            return null;
        }

        // ---- Post execute ---- //
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if(mOnImageDownloaded != null)
                mOnImageDownloaded.onSuccess(bitmap);
        }
    }
}